#ifndef LIBRERIA_H
#define LIBRERIA_H

#include <stdio.h>
#include <stdlib.h>


int calcular_triangular(int);
void comprobar_errores(int, char const *[]);

#endif
