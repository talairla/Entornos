#include <stdio.h>

int main(int argc, char const *argv[])
{
	printf("Hola %s\n", argv[1] );
	return 0;
}