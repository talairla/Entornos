#!/bin/bash
echo Hola $USER