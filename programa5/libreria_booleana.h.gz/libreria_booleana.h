#ifndef LIBRERIA_BOOLEANA_H  //Definición de
#define LIBRERIA_BOOLEANA_H	 //guardianes

#include <stdbool.h>

bool es_numero(char);
bool es_letra(char);
bool es_letra_mayuscula(char);
bool es_letra_minuscula(char);
bool es_alfanumerico(char);

#endif  //fin de la definición con guardianes